package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;
import com.capgemini.tcc.util.DBConnection;

public class PatientDAO implements IPatientDAO {
	/*****************************************************************
	 *  - Method Name:addPatientDetails 
	 *  - Input Parameters : PatientBean
	 *  - Return Type : integer
	 *  - Throws : ClinicException 
	 *  - Author : SrilekhaGamidi
	 *  - Creation Date : 22/11/2017
	 *  - Description : Adds Patient Details into the DataBase
	 *******************************************************************/
	@Override
	public int addPatientDetails(PatientBean patient) throws ClinicException{
		int patient_id=0;
		int records = 0;
		boolean isInserted = false;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection();
			PreparedStatement preparedStatement= 
			connPatient.prepareStatement(QueryMapperTCC.ADD_PATIENT);
			PreparedStatement pst = 
						connPatient.prepareStatement(QueryMapperTCC.SHOW_ID);
			){
			java.sql.Date consultationDate = Date.valueOf(LocalDate.now());
			
			preparedStatement.setString(1, patient.getPatientName());
			preparedStatement.setInt(2, patient.getAge());
			preparedStatement.setString(3,patient.getPhone() );
			preparedStatement.setString(4,patient.getDescription());
			preparedStatement.setDate(5, consultationDate);
			
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			
			}
			ResultSet rsPatient = pst.executeQuery();
			if(isInserted){
			if(rsPatient.next()){
				patient_id = rsPatient.getInt(1);
			}
			}
		}catch(SQLException sqlEx){
			throw new ClinicException(sqlEx.getMessage());
		}
		return patient_id;
	}
	/*****************************************************************
	 *  - Method Name:getPatientDetails 
	 *  - Input Parameters : patientId(integer Type)
	 *  - Return Type : PAatientBean
	 *  - Throws : ClinicException 
	 *  - Author : SrilekhaGamidi
	 *  - Creation Date : 22/11/2017
	 *  - Description : search Patient Details by PatientId 
	 *******************************************************************/
	@Override
	public PatientBean getPatientDetails(int patientId)throws ClinicException {

		PatientBean patientBean = new PatientBean();
		
		try(Connection connpatientBean = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
						connpatientBean.prepareStatement(QueryMapperTCC.SEARCH_PATIENT);			
				){
			preparedStatement.setInt(1, patientId);
		
			ResultSet rspatientBean = preparedStatement.executeQuery();
				while(rspatientBean.next()){
							
					patientBean.setPatientName(rspatientBean.getString("patient_name"));
					patientBean.setAge(rspatientBean.getInt("age"));
					patientBean.setPhone(rspatientBean.getString("phone"));
					patientBean.setDescription(rspatientBean.getString("description"));
					patientBean.setConsultationDate(rspatientBean.getDate("consultation_date"));
				}
				
			
				
		}catch(SQLException sqlEx){
			throw new ClinicException(sqlEx.getMessage());
        	}
		return patientBean;			
	}

	
}

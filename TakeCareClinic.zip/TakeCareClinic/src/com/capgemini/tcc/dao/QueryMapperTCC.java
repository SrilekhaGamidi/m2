package com.capgemini.tcc.dao;

public interface QueryMapperTCC {
 public static final String ADD_PATIENT="INSERT INTO Patient VALUES(Patient_Id_Seq.NEXTVAL,?,?,?,?,?)";
	
public static final String SEARCH_PATIENT="SELECT patient_name,age,phone,description,consultation_date FROM Patient WHERE patient_id=?";
public static final String SHOW_ID ="SELECT Patient_Id_Seq.CURRVAL FROM DUAL";

}

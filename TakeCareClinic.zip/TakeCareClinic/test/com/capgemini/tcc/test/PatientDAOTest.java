package com.capgemini.tcc.test;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.ClinicException;

public class PatientDAOTest {
	private IPatientDAO patientDao;
	@Before
	public void setUp() throws Exception {
		 patientDao=new PatientDAO();
	}

	@After
	public void tearDown() throws Exception {
		patientDao=null;
	}

	@Test
	public void testAddPatientDetails() {
		int patientid=0;
		
		try{
			PatientBean patient=new PatientBean("abc",20,"4569871236","Fever");
			patientid=patientDao.addPatientDetails(patient);
			assertTrue("Not Inserted",patientid>=1000);
		}catch(ClinicException e){
			e.printStackTrace();
		
		}
	}
	@Test
	public void testSearchPatient(){
		PatientBean patient=null;
		try{
			patient=patientDao.getPatientDetails(1002);
			assertTrue("Not Inserted",patient!=null);
		}catch(ClinicException e){
			e.printStackTrace();
		
		}
	}
}

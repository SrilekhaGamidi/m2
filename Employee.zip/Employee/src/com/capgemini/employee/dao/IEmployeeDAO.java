package com.capgemini.employee.dao;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;


public interface IEmployeeDAO {
	
	public boolean insertEmployee(final EmployeeBean employeeBean)
			throws EmployeesException;
			
			public boolean deleteEmployee(final int id)
			throws EmployeesException;
			
			public List<EmployeeBean> viewAll()
					throws EmployeesException;

}

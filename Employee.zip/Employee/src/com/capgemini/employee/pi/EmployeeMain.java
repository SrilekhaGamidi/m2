package com.capgemini.employee.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;
import com.capgemini.employee.service.IServiceEmployees;
import com.capgemini.employee.service.ServiceEmployeesImpl;

public class EmployeeMain {
	//preet
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		
		EmployeeBean employeeBean = null;
		IServiceEmployees serviceEmployees = null;
	
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Employee Details  ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Employee ");
			System.out.println("2.Delete Employee");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:
						employeeBean = populateEmployeeBean();
						serviceEmployees = new ServiceEmployeesImpl();
						try {
							boolean isInserted = serviceEmployees.insertEmployees(employeeBean);
						if(isInserted){
							System.out.println("Employee details  has been successfully registered ");
						}
						}
						catch (EmployeesException employeesException) {
						
						System.out.println("ERROR : "+ employeesException.getMessage());
						}
							break;
				case 2:
						serviceEmployees = new ServiceEmployeesImpl();
						System.out.println("Enter numeric employee id:");
						int id = sc.nextInt();
						try {
						
						boolean isDeleted = serviceEmployees.deleteMobile(id);
						if(isDeleted){
							System.out.println("Employee details  has been deleted successfully registered ");
						}
						else{
							System.out.println("There are no employee details associated with donor id "+ id);
						}
						
						} catch (EmployeesException employeesException) {
						
						System.out.println("ERROR : "+ employeesException.getMessage());
						} 
							break;
				case 3:

					serviceEmployees = new ServiceEmployeesImpl();
					try {
						List<EmployeeBean> mobileList = new ArrayList<EmployeeBean>();
						mobileList = serviceEmployees.viewAll();

						if (mobileList != null) {
							Iterator<EmployeeBean> i = mobileList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

					}

					catch (EmployeesException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
					break;
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			

		}	// end of while
	}		// end of try

		/*
		 * This function will call the service layer method and return the bean
		 * object which is populated by the information of the given EmployeeId in
		 * parameter
		 */

	private static EmployeeBean populateEmployeeBean() {

		EmployeeBean employeeBean = new EmployeeBean();;

		System.out.println("\n Enter Details");
		System.out.println("Enter Employee name: ");
		employeeBean.setName(sc.next());

		System.out.println("Enter Employee id: ");
		employeeBean.setId(sc.nextInt());

		
		System.out.println("Enter Salary: ");

		try {
			employeeBean.setSalary(sc.nextFloat());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for Salary, try again");
			}

		
		return employeeBean;

	}

}

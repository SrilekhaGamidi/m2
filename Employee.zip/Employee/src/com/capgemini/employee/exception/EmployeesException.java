package com.capgemini.employee.exception;

public class EmployeesException extends Exception {
	
private static final long serialVersionUID = 4473513424240627536L;
	
	public EmployeesException(){
		super();
	}

	public EmployeesException(String message) {
		super(message);
		
	}

}

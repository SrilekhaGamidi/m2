package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;

public interface IServiceEmployees {
	
	public boolean insertEmployees(EmployeeBean employeeBean)
			throws EmployeesException;
	
	public List<EmployeeBean> viewAll() throws EmployeesException;
	
	public boolean deleteMobile(int id) throws EmployeesException;

}
